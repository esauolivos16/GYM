let menuVisible = false;

// Funciones originales del menú responsive (las que tú tenías)
function mostrarOcultarMenu(){
    if(menuVisible){
        document.getElementById("nav").classList = "";
        menuVisible = false;
    }else{
        document.getElementById("nav").classList = "responsive";
        menuVisible = true;
    }
}

function seleccionar(){
    // Oculta el menú una vez que selecciono una opción
    document.getElementById("nav").classList = "";
    menuVisible = false;
}

// Nuevas funciones para el sistema de login
let usuarioLogueado = null;

function mostrarLogin() {
    document.getElementById('login-modal').style.display = 'flex';
    return false;
}

function cerrarLogin() {
    document.getElementById('login-modal').style.display = 'none';
    document.getElementById('formulario-login').reset();
}

function iniciarSesion(event) {
    event.preventDefault();
    const usuario = document.getElementById('usuario').value;
    const contrasena = document.getElementById('contrasena').value;
    
    // Validación básica
    if(usuario && contrasena) {
        // Simulamos un usuario válido
        usuarioLogueado = {
            nombre: usuario,
            rutinas: [
                "Lunes: Pierna y cardio (30 min)",
                "Martes: Brazos y espalda",
                "Miércoles: Cardio intensivo (45 min)",
                "Jueves: Pecho y hombros",
                "Viernes: Full body"
            ],
            dieta: [
                "Desayuno: Avena con proteína y frutas",
                "Media mañana: Batido de proteínas",
                "Almuerzo: Pechuga con arroz integral",
                "Merienda: Yogur griego con nueces",
                "Cena: Salmón con vegetales"
            ],
            entrenador: {
                nombre: "Alejandro Martínez",
                especialidad: "Fitness y musculación",
                contacto: "coach.alejandro@thegym.com",
                proximaSesion: "Jueves 15:00 hrs"
            },
            membresia: {
                tipo: "Premium (acceso ilimitado)",
                diasRestantes: 20,
                proximoPago: "15/06/2023",
                historial: "Cliente desde 01/2022"
            }
        };
        
        // Actualizar la interfaz
        document.getElementById('login-modal').style.display = 'none';
        document.getElementById('login-btn').style.display = 'none';
        document.getElementById('logout-btn').style.display = 'inline-block';
        document.getElementById('panel-cliente').style.display = 'block';
        
        // Cerrar el menú responsive si está abierto
        if(menuVisible) {
            mostrarOcultarMenu();
        }
    }
}

function cerrarSesion() {
    usuarioLogueado = null;
    document.getElementById('login-btn').style.display = 'inline-block';
    document.getElementById('logout-btn').style.display = 'none';
    document.getElementById('panel-cliente').style.display = 'none';
    return false;
}

// Cerrar modal al hacer clic fuera de él
window.onclick = function(event) {
    const modal = document.getElementById('login-modal');
    if (event.target == modal) {
        cerrarLogin();
    }
}

// Inicialización después de que cargue el DOM
document.addEventListener('DOMContentLoaded', function() {
    // Configurar el botón de oferta especial
    const btnOferta = document.querySelector('.btn-oferta');
    if(btnOferta) {
        btnOferta.addEventListener('click', function(e) {
            e.preventDefault();
            alert('¡Oferta aplicada! Un asesor se comunicará contigo.');
        });
    }
});